/**
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
 */

#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "dictionary.h"
#define LETTERS 26

typedef struct node
{
    char words[LENGTH+1];
    struct node* next;
}
node;

node* head[LETTERS] = {};

int NUM = 0;
int counter = 0;

int hash_function(char* key);
node* GetNewNode(char* s);
node* insert(char* s);

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word)
{
    // TODO
    /* put the word through the hash function, then make a crawler node to go through the hash table 
    strcmping all the way only returning true if we find a 0.
    */
    char* s = malloc((sizeof(char)*LENGTH)+1);
    *s = *word;
    NUM = hash_function(s);
    node* crawler = malloc(sizeof(node));
    
    for(int i = 0; i < (strlen(word))+1; i++)
    {
    crawler->words[i] = word[i];
    }
    crawler->next = head[NUM];
    while(crawler->next != NULL)
    {
        if (strcmp(((crawler)->words), head[NUM]->words) != 0)
        {
            crawler = crawler->next;
            for(int i = 0; i < (strlen(word)+1); i++)
            {
            crawler->words[i] = word[i];
            }
        }
        else
        {
            free(crawler);
            free(s);
            return true;
        }
        free(crawler);
        free(s);
        return false;
    }
    return false;
}


/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
bool load(const char* dictionary)
{
    // TODO
    /* open the dictionary, read through the dictionary, adding a word to a hash table.
    
    char buffer[256] = 0;
    
    
    strcat(buffer, dictionary);
    */
    FILE* dict = fopen(dictionary, "r");
    if (dict == NULL)
    {
    return false;
    }
    else
    {
    char* s = malloc((sizeof(char)*LENGTH)+1);
    while(fgets(s, (sizeof(char))*LENGTH, dict) != NULL)
    {
        NUM = hash_function(s);
        head[NUM] = insert(s);
        counter++;
    }
    free (s);
    fclose(dict);
    return true;
    }
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    if(counter >0)
    {
        return counter;
    }
    else
    {
    return 0;
    }
}

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
bool unload(void)
{
    for(int i = 0; i < LETTERS; i++)
    {
       if(head[i] != NULL) 
       {
        node* crawlerNode = head[i];
        while(crawlerNode != NULL)
            {
                node* temp = crawlerNode->next;
                free (crawlerNode);
                crawlerNode = temp;
            }
        return true;
       }
       else
       {
           return false;
       }
        
    }
    return false;
}
    
    

int hash_function(char* key)
{
    int hash = toupper(key[0])-'A';
    
    return hash % LETTERS;
}

node* GetNewNode(char* s) 
{
	node* newNode = malloc(sizeof(struct node));
	for(int i = 0; i<(strlen(s)+1); i++)
	{
	newNode->words[i] = s[i];
	}
	newNode->next = NULL;
	return newNode;
}

node* insert(char* s)
{
    struct node* newNode = GetNewNode(s);
	if(head[NUM] == NULL) 
	{
		head[NUM] = newNode;
		return head[NUM];
	}
	newNode->next = head[NUM]; 
	head[NUM] = newNode;
	return head[NUM];

}